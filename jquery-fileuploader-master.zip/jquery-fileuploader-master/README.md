

Changelog:

Version 1.3:
1. Html5 Drag and Drop Support
2. Html5 Multiple Select
3. Added Auto Upload feature
4. Html5 upload progress using jquery ui
5. Add Mock progress bar for iframe upload
6. Use jquery ui themes for layout and buttons
7. Uses jquery ui progressBar and button plugin
8. Use jquery.ajax to upload html5 files
9. Add Individual upload button	

Version 1.2:
1. handles other form input
2. Added beforeUpload, beforeEachUpload, afterUpload, and afterEachUpload callbacks
3. Removed callback, inputName, and inputSize config
4. Can now initialize multiple script in a single page
5. Restructured Code and use jquery 1.4 features

	
## License
Released under the [MIT license](http://www.opensource.org/licenses/MIT).